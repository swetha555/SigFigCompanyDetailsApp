1. I tried using routing to populate partials, injection and  directies, but it wasnt allowing me. I am not sure why this was happening. Thats the reason i had created everything in a single file script.js. ng-view isnt responding at all.

2. I wanted to use Bower to update node modules and angular, but you said you need only testcode files not the package.json file, so couldnot put my dependencies, I am just using google cdn links for most of my dependencies with angular and bootstrap.

3. I didnot use css preprocessor(less) for the same reason.

About the App:
----------------
1. You can populate company details on the launch page.
2. When you click on the People who work at #company, list of persons populate in the ollapsible panel.
3. Click on the Comapny name to navigate to company details view. 
4. The mockups were not giving me complete information for the companies and persons display, i used toggle collapse panel. I used my imagination here.
5. You can also toggle the people who work here panel and see the list ofpersons working under this company.
6. I am hiding the add company and person panels at screen widths less than or equal to mobile.

